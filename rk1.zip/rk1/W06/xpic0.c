#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <stdio.h>
#include <stdlib.h>
#include "xpic.h"

static Display *dpy;
static Window root_win;
static GC gc;
static unsigned long colors_pixel[3];
static int done = 0;

/* Прототипы внутренних функций */
static void draw_cell(unsigned row, unsigned col);
static void redraw_all(void);
static void handle_button(XEvent *ev);
static int handle_key(XEvent *ev);

static unsigned long color_to_pixel(unsigned char c) {
    if (c == COLOR_RED) return colors_pixel[0];
    if (c == COLOR_GREEN) return colors_pixel[1];
    return colors_pixel[2];
}

static void draw_cell(unsigned row, unsigned col) {
    Window win = cells[row][col];
    int sz = CELL_SIZE;
    XPoint points[3];
    int diag = ((row + col) % 2 == 0) ? 0 : 1;
    unsigned char col_top = top_color[row][col];
    unsigned char col_bot = bottom_color[row][col];

    if (diag == 0) { /* диагональ '/' */
        points[0].x = 0; points[0].y = 0;
        points[1].x = sz; points[1].y = 0;
        points[2].x = 0; points[2].y = sz;
        XSetForeground(dpy, gc, color_to_pixel(col_top));
        XFillPolygon(dpy, win, gc, points, 3, Convex, CoordModeOrigin);

        points[0].x = sz; points[0].y = 0;
        points[1].x = sz; points[1].y = sz;
        points[2].x = 0; points[2].y = sz;
        XSetForeground(dpy, gc, color_to_pixel(col_bot));
        XFillPolygon(dpy, win, gc, points, 3, Convex, CoordModeOrigin);
    } else { /* диагональ '\' */
        points[0].x = sz; points[0].y = 0;
        points[1].x = sz; points[1].y = sz;
        points[2].x = 0; points[2].y = 0;
        XSetForeground(dpy, gc, color_to_pixel(col_top));
        XFillPolygon(dpy, win, gc, points, 3, Convex, CoordModeOrigin);

        points[0].x = 0; points[0].y = 0;
        points[1].x = 0; points[1].y = sz;
        points[2].x = sz; points[2].y = sz;
        XSetForeground(dpy, gc, color_to_pixel(col_bot));
        XFillPolygon(dpy, win, gc, points, 3, Convex, CoordModeOrigin);
    }

    XSetForeground(dpy, gc, BlackPixel(dpy, DefaultScreen(dpy)));
    if (diag == 0)
        XDrawLine(dpy, win, gc, 0, 0, sz, sz);
    else
        XDrawLine(dpy, win, gc, sz, 0, 0, sz);
}

static void redraw_all(void) {
    for (unsigned i = 0; i < NY; i++)
        for (unsigned j = 0; j < NX; j++)
            draw_cell(i, j);
    XFlush(dpy);
}

int xcustom(void) {
    int scr = DefaultScreen(dpy);
    int depth = DefaultDepth(dpy, scr);
    Window root = RootWindow(dpy, scr);
    XSetWindowAttributes attr;
    unsigned long amask;
    XSizeHints hint;
    Colormap cmap = DefaultColormap(dpy, scr);
    XColor xcol;

    XParseColor(dpy, cmap, "red", &xcol);
    XAllocColor(dpy, cmap, &xcol);
    colors_pixel[0] = xcol.pixel;
    XParseColor(dpy, cmap, "green", &xcol);
    XAllocColor(dpy, cmap, &xcol);
    colors_pixel[1] = xcol.pixel;
    XParseColor(dpy, cmap, "blue", &xcol);
    XAllocColor(dpy, cmap, &xcol);
    colors_pixel[2] = xcol.pixel;

    unsigned win_w = NX * CELL_SIZE;
    unsigned win_h = NY * CELL_SIZE;
    attr.override_redirect = False;
    attr.background_pixel = WhitePixel(dpy, scr);
    amask = CWOverrideRedirect | CWBackPixel;
    root_win = XCreateWindow(dpy, root, 0, 0, win_w, win_h, 1, depth,
                             InputOutput, CopyFromParent, amask, &attr);
    hint.flags = PMinSize | PMaxSize | PPosition;
    hint.min_width = hint.max_width = win_w;
    hint.min_height = hint.max_height = win_h;
    hint.x = hint.y = 0;
    XSetNormalHints(dpy, root_win, &hint);
    XStoreName(dpy, root_win, "xpic - 3-color pictogram");

    amask = CWOverrideRedirect | CWBackPixel | CWEventMask;
    attr.override_redirect = True;
    attr.background_pixel = WhitePixel(dpy, scr);
    attr.event_mask = ExposureMask | ButtonPressMask;
    for (unsigned i = 0; i < NY; i++) {
        for (unsigned j = 0; j < NX; j++) {
            cells[i][j] = XCreateWindow(dpy, root_win,
                                        j * CELL_SIZE, i * CELL_SIZE,
                                        CELL_SIZE, CELL_SIZE, 0, depth,
                                        InputOutput, CopyFromParent,
                                        amask, &attr);
            XSelectInput(dpy, cells[i][j], ExposureMask | ButtonPressMask);
        }
    }

    XMapWindow(dpy, root_win);
    for (unsigned i = 0; i < NY; i++)
        for (unsigned j = 0; j < NX; j++)
            XMapWindow(dpy, cells[i][j]);

    gc = XCreateGC(dpy, root_win, 0, NULL);
    XSetLineAttributes(dpy, gc, 1, LineSolid, CapButt, JoinMiter);
    return 0;
}

static void handle_button(XEvent *ev) {
    Window w = ev->xbutton.window;
    unsigned row = 0, col = 0;
    int found = 0;
    for (row = 0; row < NY && !found; row++) {
        for (col = 0; col < NX; col++) {
            if (cells[row][col] == w) {
                found = 1;
                break;
            }
        }
    }
    if (!found) return;
    row--; col--;

    int x = ev->xbutton.x;
    int y = ev->xbutton.y;
    int sz = CELL_SIZE;
    int diag = ((row + col) % 2 == 0) ? 0 : 1;
    int triangle = -1;

    if (diag == 0) { /* '/' */
        triangle = (y < x) ? 0 : 1;
    } else { /* '\' */
        triangle = (y < sz - x) ? 0 : 1;
    }

    unsigned char new_color;
    if (ev->xbutton.button == Button1) new_color = COLOR_RED;
    else if (ev->xbutton.button == Button2) new_color = COLOR_GREEN;
    else if (ev->xbutton.button == Button3) new_color = COLOR_BLUE;
    else return;

    set_triangle_color(row, col, triangle, new_color);
    draw_cell(row, col);
    XFlush(dpy);
}

static int handle_key(XEvent *ev) {
    KeySym ks = XLookupKeysym((XKeyEvent*)ev, 0);
    switch (ks) {
        case XK_Escape:
            return 1;
        case XK_R: case XK_r:
            for (unsigned i = 0; i < NY; i++)
                for (unsigned j = 0; j < NX; j++) {
                    set_triangle_color(i, j, 0, COLOR_RED);
                    set_triangle_color(i, j, 1, COLOR_RED);
                }
            redraw_all();
            break;
        case XK_G: case XK_g:
            for (unsigned i = 0; i < NY; i++)
                for (unsigned j = 0; j < NX; j++) {
                    set_triangle_color(i, j, 0, COLOR_GREEN);
                    set_triangle_color(i, j, 1, COLOR_GREEN);
                }
            redraw_all();
            break;
        case XK_B: case XK_b:
            for (unsigned i = 0; i < NY; i++)
                for (unsigned j = 0; j < NX; j++) {
                    set_triangle_color(i, j, 0, COLOR_BLUE);
                    set_triangle_color(i, j, 1, COLOR_BLUE);
                }
            redraw_all();
            break;
        default: break;
    }
    return 0;
}

int dispatch(void) {
    XEvent ev;
    while (!done) {
        XNextEvent(dpy, &ev);
        switch (ev.type) {
            case Expose:
                if (ev.xexpose.count == 0) {
                    Window w = ev.xexpose.window;
                    for (unsigned i = 0; i < NY; i++)
                        for (unsigned j = 0; j < NX; j++)
                            if (cells[i][j] == w) {
                                draw_cell(i, j);
                                break;
                            }
                }
                break;
            case ButtonPress:
                handle_button(&ev);
                break;
            case KeyPress:
                done = handle_key(&ev);
                break;
            default:
                break;
        }
    }
    return 0;
}

int main(int argc, char *argv[]) {
    unsigned ny = 8, nx = 8, cell_sz = 60;
    if (argc >= 4) {
        ny = atoi(argv[1]);
        nx = atoi(argv[2]);
        cell_sz = atoi(argv[3]);
        if (ny == 0) ny = 8;
        if (nx == 0) nx = 8;
        if (cell_sz < 10) cell_sz = 10;
    } else if (argc == 2) {
        sscanf(argv[1], "%ux%u", &nx, &ny);
        cell_sz = 60;
    } else {
        fprintf(stderr, "Usage: %s rows cols cell_size  or  %s WxH\n", argv[0], argv[0]);
        fprintf(stderr, "Using defaults: 8x8, cell size 60\n");
    }

    if (alloc(ny, nx, cell_sz) != 0) {
        fprintf(stderr, "Memory allocation failed\n");
        return 1;
    }
    init_colors();

    dpy = XOpenDisplay(NULL);
    if (!dpy) {
        fprintf(stderr, "Cannot open display\n");
        dealloc();
        return 1;
    }

    if (xcustom() != 0) {
        fprintf(stderr, "X11 initialization failed\n");
        XCloseDisplay(dpy);
        dealloc();
        return 1;
    }

    redraw_all();
    dispatch();

    XDestroySubwindows(dpy, root_win);
    XDestroyWindow(dpy, root_win);
    XCloseDisplay(dpy);
    dealloc();
    return 0;
}