#include <stdlib.h>
#include <stdio.h>
#include "xpic.h"

/* Определение глобальных переменных */
unsigned NY = 0;
unsigned NX = 0;
unsigned CELL_SIZE = 0;
unsigned char **top_color = NULL;
unsigned char **bottom_color = NULL;
Window **cells = NULL;

/* Выделение памяти */
int alloc(unsigned ny, unsigned nx, unsigned cell_size) {
    NY = ny;
    NX = nx;
    CELL_SIZE = cell_size;

    top_color = (unsigned char **)calloc(NY, sizeof(unsigned char *));
    bottom_color = (unsigned char **)calloc(NY, sizeof(unsigned char *));
    if (!top_color || !bottom_color) return -1;

    for (unsigned i = 0; i < NY; i++) {
        top_color[i] = (unsigned char *)calloc(NX, sizeof(unsigned char));
        bottom_color[i] = (unsigned char *)calloc(NX, sizeof(unsigned char));
        if (!top_color[i] || !bottom_color[i]) return -1;
    }

    cells = (Window **)calloc(NY, sizeof(Window *));
    if (!cells) return -1;
    for (unsigned i = 0; i < NY; i++) {
        cells[i] = (Window *)calloc(NX, sizeof(Window));
        if (!cells[i]) return -1;
    }
    return 0;
}

/* Освобождение памяти */
void dealloc(void) {
    if (top_color) {
        for (unsigned i = 0; i < NY; i++) free(top_color[i]);
        free(top_color);
        top_color = NULL;
    }
    if (bottom_color) {
        for (unsigned i = 0; i < NY; i++) free(bottom_color[i]);
        free(bottom_color);
        bottom_color = NULL;
    }
    if (cells) {
        for (unsigned i = 0; i < NY; i++) free(cells[i]);
        free(cells);
        cells = NULL;
    }
}

/* Начальная инициализация – все треугольники красные */
void init_colors(void) {
    for (unsigned i = 0; i < NY; i++) {
        for (unsigned j = 0; j < NX; j++) {
            top_color[i][j] = COLOR_RED;
            bottom_color[i][j] = COLOR_RED;
        }
    }
}

/* Установка цвета треугольника: triangle = 0 – верхний, 1 – нижний */
void set_triangle_color(unsigned row, unsigned col, int triangle, unsigned char color) {
    if (row >= NY || col >= NX) return;
    if (triangle == 0)
        top_color[row][col] = color;
    else
        bottom_color[row][col] = color;
}

/* Получение цвета треугольника */
unsigned char get_triangle_color(unsigned row, unsigned col, int triangle) {
    if (row >= NY || col >= NX) return COLOR_RED;
    return (triangle == 0) ? top_color[row][col] : bottom_color[row][col];
}