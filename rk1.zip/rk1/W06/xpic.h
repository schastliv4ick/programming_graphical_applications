#ifndef XPIC_H
#define XPIC_H

#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

#define COLOR_RED   0
#define COLOR_GREEN 1
#define COLOR_BLUE  2

extern unsigned NY;
extern unsigned NX;
extern unsigned CELL_SIZE;
extern unsigned char **top_color;
extern unsigned char **bottom_color;
extern Window **cells;

int alloc(unsigned ny, unsigned nx, unsigned cell_size);
void dealloc(void);
void init_colors(void);
void set_triangle_color(unsigned row, unsigned col, int triangle, unsigned char color);
unsigned char get_triangle_color(unsigned row, unsigned col, int triangle);

/* Функции графического модуля, вызываемые из main */
int xcustom(void);
int dispatch(void);

#endif