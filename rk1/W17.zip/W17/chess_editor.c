#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>

#define BOARD_SIZE 8
#define CELL_SIZE 60
#define WIN_WIDTH (BOARD_SIZE * CELL_SIZE)
#define WIN_HEIGHT (BOARD_SIZE * CELL_SIZE)

/* Типы фигур */
typedef enum {
    PIECE_KING = 'K',
    PIECE_QUEEN = 'Q',
    PIECE_ROOK = 'R',
    PIECE_BISHOP = 'B',
    PIECE_KNIGHT = 'N'
} PieceType;

/* Структура фигуры */
typedef struct {
    Window win;
    PieceType type;
    int row, col;
    int start_row, start_col;
} Piece;

/* Глобальные переменные */
Display *dpy;
Window main_win;
Window cell_windows[BOARD_SIZE][BOARD_SIZE];
Piece pieces[BOARD_SIZE];
int num_pieces = 0;
int occupied[BOARD_SIZE][BOARD_SIZE];
int threats[BOARD_SIZE][BOARD_SIZE];

/* Pixel может быть не определён, добавим явно */
#ifndef Pixel
typedef unsigned long Pixel;
#endif

Pixel color_light, color_dark;
Pixel color_threat;
Pixel color_piece_bg;
GC text_gc;
XFontStruct *font_info;

/* Прототипы всех функций */
void init_colors(void);
void create_cell_windows(void);
void create_piece_windows(void);
void draw_piece_text(Window win, PieceType type);
void update_cell_colors(void);
void compute_threats(void);
void move_piece(int piece_idx, int new_row, int new_col);
void reset_positions(void);
void free_resources(void);
static int in_board(int r, int c);

/* Инициализация цветов */
void init_colors(void) {
    Colormap cmap = DefaultColormap(dpy, DefaultScreen(dpy));
    XColor xcol;

    XParseColor(dpy, cmap, "bisque2", &xcol);
    XAllocColor(dpy, cmap, &xcol);
    color_light = xcol.pixel;

    XParseColor(dpy, cmap, "burlywood4", &xcol);
    XAllocColor(dpy, cmap, &xcol);
    color_dark = xcol.pixel;

    XParseColor(dpy, cmap, "lightcoral", &xcol);
    XAllocColor(dpy, cmap, &xcol);
    color_threat = xcol.pixel;

    XParseColor(dpy, cmap, "white", &xcol);
    XAllocColor(dpy, cmap, &xcol);
    color_piece_bg = xcol.pixel;
}

/* Создание окон для клеток доски */
void create_cell_windows(void) {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            int x = j * CELL_SIZE;
            int y = i * CELL_SIZE;
            Pixel bg = ((i + j) % 2 == 0) ? color_light : color_dark;
            cell_windows[i][j] = XCreateSimpleWindow(dpy, main_win,
                                                      x, y, CELL_SIZE, CELL_SIZE, 1,
                                                      BlackPixel(dpy, DefaultScreen(dpy)),
                                                      bg);
            XSelectInput(dpy, cell_windows[i][j], ButtonPressMask);
            XMapWindow(dpy, cell_windows[i][j]);
        }
    }
}

/* Создание окон для фигур */
void create_piece_windows(void) {
    /* Начальные позиции и типы (белые фигуры на 0-й горизонтали) */
    const int start_positions[8][2] = {
        {0,0},{0,1},{0,2},{0,3},{0,4},{0,5},{0,6},{0,7}
    };
    const PieceType start_types[8] = {
        PIECE_ROOK, PIECE_KNIGHT, PIECE_BISHOP, PIECE_QUEEN,
        PIECE_KING, PIECE_BISHOP, PIECE_KNIGHT, PIECE_ROOK
    };

    for (int idx = 0; idx < 8; idx++) {
        int row = start_positions[idx][0];
        int col = start_positions[idx][1];
        int x = col * CELL_SIZE;
        int y = row * CELL_SIZE;
        pieces[idx].type = start_types[idx];
        pieces[idx].row = row;
        pieces[idx].col = col;
        pieces[idx].start_row = row;
        pieces[idx].start_col = col;
        pieces[idx].win = XCreateSimpleWindow(dpy, main_win,
                                              x, y, CELL_SIZE, CELL_SIZE, 1,
                                              BlackPixel(dpy, DefaultScreen(dpy)),
                                              color_piece_bg);
        XSelectInput(dpy, pieces[idx].win, ButtonPressMask | ExposureMask);
        XMapWindow(dpy, pieces[idx].win);
        draw_piece_text(pieces[idx].win, pieces[idx].type);
        occupied[row][col] = idx;
    }
    num_pieces = 8;
}

/* Рисование буквы в окне фигуры */
void draw_piece_text(Window win, PieceType type) {
    char str[2] = { (char)type, '\0' };
    int tw = XTextWidth(font_info, str, 1);
    int th = font_info->ascent + font_info->descent;
    int x = (CELL_SIZE - tw) / 2;
    int y = (CELL_SIZE - th) / 2 + font_info->ascent;
    XSetForeground(dpy, text_gc, BlackPixel(dpy, DefaultScreen(dpy)));
    XDrawString(dpy, win, text_gc, x, y, str, 1);
    XFlush(dpy);
}

/* Обновление цвета фона клеток с учётом угроз */
void update_cell_colors(void) {
    for (int i = 0; i < BOARD_SIZE; i++) {
        for (int j = 0; j < BOARD_SIZE; j++) {
            Window win = cell_windows[i][j];
            Pixel normal_bg = ((i + j) % 2 == 0) ? color_light : color_dark;
            Pixel new_bg = threats[i][j] ? color_threat : normal_bg;
            XSetWindowBackground(dpy, win, new_bg);
            XClearWindow(dpy, win);
        }
    }
    XFlush(dpy);
}

/* Проверка, что клетка на доске */
static int in_board(int r, int c) {
    return r >= 0 && r < BOARD_SIZE && c >= 0 && c < BOARD_SIZE;
}

/* Вычисление угроз для всех фигур */
void compute_threats(void) {
    /* Сброс угроз */
    for (int i = 0; i < BOARD_SIZE; i++)
        for (int j = 0; j < BOARD_SIZE; j++)
            threats[i][j] = 0;

    /* Для каждой фигуры */
    for (int idx = 0; idx < num_pieces; idx++) {
        int r = pieces[idx].row;
        int c = pieces[idx].col;
        PieceType type = pieces[idx].type;

        switch (type) {
            case PIECE_KING:
                for (int dr = -1; dr <= 1; dr++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        if (dr == 0 && dc == 0) continue;
                        int nr = r + dr, nc = c + dc;
                        if (in_board(nr, nc) && occupied[nr][nc] == -1)
                            threats[nr][nc] = 1;
                    }
                }
                break;

            case PIECE_QUEEN:
                for (int dr = -1; dr <= 1; dr++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        if (dr == 0 && dc == 0) continue;
                        int nr = r + dr, nc = c + dc;
                        while (in_board(nr, nc)) {
                            if (occupied[nr][nc] != -1) break;
                            threats[nr][nc] = 1;
                            nr += dr; nc += dc;
                        }
                    }
                }
                break;

            case PIECE_ROOK:
                for (int dr = -1; dr <= 1; dr++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        if ((dr == 0) == (dc == 0)) continue; /* только ортогональ */
                        int nr = r + dr, nc = c + dc;
                        while (in_board(nr, nc)) {
                            if (occupied[nr][nc] != -1) break;
                            threats[nr][nc] = 1;
                            nr += dr; nc += dc;
                        }
                    }
                }
                break;

            case PIECE_BISHOP:
                for (int dr = -1; dr <= 1; dr++) {
                    for (int dc = -1; dc <= 1; dc++) {
                        if (dr == 0 || dc == 0) continue;
                        int nr = r + dr, nc = c + dc;
                        while (in_board(nr, nc)) {
                            if (occupied[nr][nc] != -1) break;
                            threats[nr][nc] = 1;
                            nr += dr; nc += dc;
                        }
                    }
                }
                break;

            case PIECE_KNIGHT:
                {
                    int moves[8][2] = {{-2,-1},{-2,1},{-1,-2},{-1,2},{1,-2},{1,2},{2,-1},{2,1}};
                    for (int k = 0; k < 8; k++) {
                        int nr = r + moves[k][0];
                        int nc = c + moves[k][1];
                        if (in_board(nr, nc) && occupied[nr][nc] == -1)
                            threats[nr][nc] = 1;
                    }
                }
                break;
        }
    }
    update_cell_colors();
}

/* Перемещение фигуры */
void move_piece(int piece_idx, int new_row, int new_col) {
    if (!in_board(new_row, new_col)) return;
    if (occupied[new_row][new_col] != -1) return;

    int old_row = pieces[piece_idx].row;
    int old_col = pieces[piece_idx].col;
    occupied[old_row][old_col] = -1;
    pieces[piece_idx].row = new_row;
    pieces[piece_idx].col = new_col;
    occupied[new_row][new_col] = piece_idx;
    int x = new_col * CELL_SIZE;
    int y = new_row * CELL_SIZE;
    XMoveWindow(dpy, pieces[piece_idx].win, x, y);
    XFlush(dpy);
    compute_threats();
}

/* Сброс в начальную расстановку */
void reset_positions(void) {
    /* Очищаем occupied */
    for (int i = 0; i < BOARD_SIZE; i++)
        for (int j = 0; j < BOARD_SIZE; j++)
            occupied[i][j] = -1;

    const int start_positions[8][2] = {
        {0,0},{0,1},{0,2},{0,3},{0,4},{0,5},{0,6},{0,7}
    };
    const PieceType start_types[8] = {
        PIECE_ROOK, PIECE_KNIGHT, PIECE_BISHOP, PIECE_QUEEN,
        PIECE_KING, PIECE_BISHOP, PIECE_KNIGHT, PIECE_ROOK
    };

    for (int idx = 0; idx < 8; idx++) {
        int new_row = start_positions[idx][0];
        int new_col = start_positions[idx][1];
        pieces[idx].row = new_row;
        pieces[idx].col = new_col;
        occupied[new_row][new_col] = idx;
        int x = new_col * CELL_SIZE;
        int y = new_row * CELL_SIZE;
        XMoveWindow(dpy, pieces[idx].win, x, y);
    }
    XFlush(dpy);
    compute_threats();
}

/* Освобождение ресурсов */
void free_resources(void) {
    for (int i = 0; i < BOARD_SIZE; i++)
        for (int j = 0; j < BOARD_SIZE; j++)
            XDestroyWindow(dpy, cell_windows[i][j]);
    for (int i = 0; i < num_pieces; i++)
        XDestroyWindow(dpy, pieces[i].win);
    if (font_info) XFreeFont(dpy, font_info);
    if (text_gc) XFreeGC(dpy, text_gc);
    XDestroyWindow(dpy, main_win);
}

int main(int argc, char *argv[]) {
    if (argc != 1) {
        fprintf(stderr, "Usage: %s\n", argv[0]);
        return 1;
    }

    dpy = XOpenDisplay(NULL);
    if (!dpy) {
        fprintf(stderr, "Cannot open display.\n");
        return 1;
    }
    int screen = DefaultScreen(dpy);

    main_win = XCreateSimpleWindow(dpy, RootWindow(dpy, screen),
                                   0, 0, WIN_WIDTH, WIN_HEIGHT, 1,
                                   BlackPixel(dpy, screen), WhitePixel(dpy, screen));
    XSelectInput(dpy, main_win, KeyPressMask);
    XMapWindow(dpy, main_win);

    init_colors();

    /* Загрузка шрифта */
    font_info = XLoadQueryFont(dpy, "fixed");
    if (!font_info) {
        font_info = XLoadQueryFont(dpy, "6x13");
        if (!font_info) {
            fprintf(stderr, "Cannot load font\n");
            return 1;
        }
    }
    text_gc = XCreateGC(dpy, main_win, 0, NULL);
    XSetFont(dpy, text_gc, font_info->fid);

    /* Инициализация occupied */
    for (int i = 0; i < BOARD_SIZE; i++)
        for (int j = 0; j < BOARD_SIZE; j++)
            occupied[i][j] = -1;

    create_cell_windows();
    create_piece_windows();
    compute_threats();

    int dragging = 0;
    int drag_piece = -1;
    int drag_x_start = 0, drag_y_start = 0;

    XEvent ev;
    int running = 1;
    while (running) {
        XNextEvent(dpy, &ev);

        switch (ev.type) {
            case KeyPress: {
                KeySym ks = XLookupKeysym(&ev.xkey, 0);
                if (ks == XK_Escape) {
                    reset_positions();
                }
                break;
            }

            case ButtonPress: {
                Window clicked = ev.xbutton.window;
                int piece_idx = -1;
                for (int i = 0; i < num_pieces; i++) {
                    if (pieces[i].win == clicked) {
                        piece_idx = i;
                        break;
                    }
                }
                if (piece_idx != -1) {
                    dragging = 1;
                    drag_piece = piece_idx;
                    drag_x_start = ev.xbutton.x;
                    drag_y_start = ev.xbutton.y;
                    XGrabPointer(dpy, clicked, True,
                                 ButtonPressMask | ButtonReleaseMask | PointerMotionMask,
                                 GrabModeAsync, GrabModeAsync, None, None, CurrentTime);
                } else {
                    /* Проверка клика по свободной клетке для выхода */
                    for (int i = 0; i < BOARD_SIZE && !running; i++) {
                        for (int j = 0; j < BOARD_SIZE; j++) {
                            if (cell_windows[i][j] == clicked && occupied[i][j] == -1) {
                                running = 0;
                                break;
                            }
                        }
                    }
                }
                break;
            }

            case MotionNotify: {
                if (dragging && drag_piece != -1) {
                    int new_x = ev.xmotion.x_root - drag_x_start;
                    int new_y = ev.xmotion.y_root - drag_y_start;
                    if (new_x < 0) new_x = 0;
                    if (new_y < 0) new_y = 0;
                    if (new_x > WIN_WIDTH - CELL_SIZE) new_x = WIN_WIDTH - CELL_SIZE;
                    if (new_y > WIN_HEIGHT - CELL_SIZE) new_y = WIN_HEIGHT - CELL_SIZE;
                    XMoveWindow(dpy, pieces[drag_piece].win, new_x, new_y);
                    XFlush(dpy);
                }
                break;
            }

            case ButtonRelease: {
                if (dragging && drag_piece != -1) {
                    XWindowAttributes attrs;
                    XGetWindowAttributes(dpy, pieces[drag_piece].win, &attrs);
                    int center_x = attrs.x + CELL_SIZE / 2;
                    int center_y = attrs.y + CELL_SIZE / 2;
                    int new_col = center_x / CELL_SIZE;
                    int new_row = center_y / CELL_SIZE;
                    if (in_board(new_row, new_col) && occupied[new_row][new_col] == -1) {
                        move_piece(drag_piece, new_row, new_col);
                    } else {
                        /* Возврат в исходную позицию */
                        int old_row = pieces[drag_piece].row;
                        int old_col = pieces[drag_piece].col;
                        XMoveWindow(dpy, pieces[drag_piece].win,
                                    old_col * CELL_SIZE, old_row * CELL_SIZE);
                        XFlush(dpy);
                    }
                    XUngrabPointer(dpy, CurrentTime);
                    dragging = 0;
                    drag_piece = -1;
                }
                break;
            }

            case Expose: {
                if (ev.xexpose.window != main_win) {
                    for (int i = 0; i < num_pieces; i++) {
                        if (pieces[i].win == ev.xexpose.window) {
                            draw_piece_text(pieces[i].win, pieces[i].type);
                            break;
                        }
                    }
                }
                break;
            }
        }
    }

    free_resources();
    XCloseDisplay(dpy);
    return 0;
}